/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ex00.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tphophan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/01 13:00:21 by tphophan          #+#    #+#             */
/*   Updated: 2022/04/07 19:31:16 by tphophan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include<stdio.h>
#include<stdlib.h>

char	*ft_strdup(char *src);

int	main(int ac, char *av[])
{
	char	*new;
	int		i;

	if (ac > 1)
	{
		i = 1;
		while (i < ac)
		{
			new = ft_strdup(av[i]);
			printf("ft_strdup (%d) = %s (%s)\n", i, new, av[i]);
			free(new);
			i++;
		}
	}
}
