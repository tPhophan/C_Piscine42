#include <stdio.h>

void ft_ft(int *nbr);

int main()
{
	int a = 45;
	ft_ft(&a);
	printf("%d",a);
}
